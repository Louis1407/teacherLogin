package model;

import javafx.beans.property.*;

public class Student {
	
	//Declaring the Student Data Columns
	//Found in the database
	
	
	private IntegerProperty studentID;
	private StringProperty name;
	private IntegerProperty age;
	
	public Student() {
		
		this.studentID = new SimpleIntegerProperty();
		this.name = new SimpleStringProperty();
		this.age = new SimpleIntegerProperty();
		
	}
	
	//Student ID Getters and Setters
	
	public int getStudentID() {
		
		return studentID.get();
	}
	
	public void setStudentID(int studentID) {
		
		this.studentID.set(studentID);
	}
	
	public IntegerProperty studentIDProperty() {
		
		return studentID;
	}
	
	//Student name getters and setters
	
	public String getStudentName() {
		
		return name.get();
	}
	
	public void setName(String name) {
		
		this.name.set(name);
	}
	
	public StringProperty nameProperty() {
		
		return name;
	}
	
	//Student age getters and setters
	
	public int getAge() {
		
		return age.get();
	}
	
	public void setAge(int age) {
		
		this.age.set(age);
	}
	
	public IntegerProperty ageProperty() {
		
		return age;
	}
}
